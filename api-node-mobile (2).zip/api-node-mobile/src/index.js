const express = require('express');
const userController = require('../src/controllers/userController');
const produtoController = require('../src/controllers/produtoController');
const armasController = require('../src/controllers/armasController');

const app = express();
app.use(express.json());
app.use('/api/users', userController);
app.use('/api/produto', produtoController);
app.use('/api/armas', armasController);

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
})
 