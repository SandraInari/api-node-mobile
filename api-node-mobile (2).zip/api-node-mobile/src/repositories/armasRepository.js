const Armas = require('../models/armas');

class ArmasRepository{
    async createArmas(armas){
        return await Armas.create(armas);
    }

    async findByName(nome){
        return await Armas.findOne({where: {nome}});
    }

    async findAll(){
        return await Armas.findAll();
    }
}

module.exports = new ArmasRepository();