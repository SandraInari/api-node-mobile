const express = require('express');
const armasService = require('../services/armasService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) =>{
    try{
        const armas = await armasService.getarmas();
        res.json(armas);
    }
    catch(error){
        res.status(400).json({error: error.message});
    }
})

router.post('/',authenticateToken, async(req,res) =>{
    const { nome,descricao, preco } = req.body;

try{
    const armas = await produtoService.register(nome,descricao, preco);
    res.status(201).json(armas);
} catch (error){
    res.status(400).json({ error: error.message})
}
});

module.exports = router;