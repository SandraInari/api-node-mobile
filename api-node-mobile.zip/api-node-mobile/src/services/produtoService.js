const bcrypt = require('bcrypt');
const produtoRepository = require('../repositories/produtoRepository'); // Repositório de produtos
const { v4: uuidv4 } = require('uuid'); // Para gerar IDs únicos
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'SUACHAVESECRETA';

class ProdutoService {
    // Função para registrar um novo produto
    async createProduto(nome, preco, descricao, categoria) {
        // Verifica se já existe um produto com o nome fornecido
        const getProduto = await this.getByNome(nome);
        if (getProduto) {
            throw new Error('Produto já cadastrado');
        }

        // Cria um novo produto no repositório
        const produto = await produtoRepository.createProduto({
            id: uuidv4(), // Gera um ID único para o produto
            nome,
            preco,
            descricao,
            categoria
        });
        return produto;
    }

    // Função para buscar um produto por nome
    async getByNome(nome) {
        return await produtoRepository.findByNome(nome);
    }

    // Função para listar todos os produtos
    async getProdutos() {
        return await produtoRepository.findAll();
    }

    // Função para atualizar um produto
    async updateProduto(id, nome, preco, descricao, categoria) {
        const produto = await produtoRepository.findById(id);
        if (!produto) {
            throw new Error('Produto não encontrado');
        }

        // Atualiza o produto no repositório
        const updatedProduto = await produtoRepository.updateProduto(id, { nome, preco, descricao, categoria });
        return updatedProduto;
    }

    // Função para excluir um produto
    async deleteProduto(id) {
        const produto = await produtoRepository.findById(id);
        if (!produto) {
            throw new Error('Produto não encontrado');
        }

        await produtoRepository.deleteProduto(id);
        return { message: 'Produto excluído com sucesso' };
    }
}

module.exports = new ProdutoService();
