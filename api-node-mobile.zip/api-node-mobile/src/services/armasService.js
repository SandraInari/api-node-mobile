const bcrypt = require('bcrypt');
const armasRepository = require('../repositories/armasRepository');
const { v4: UUIDV4 } = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'SUACHAVESECRETA';

class ArmasService{
    async register(nome,descricao, preco){
        const getarmas = await this.getByName(nome);
        console.log(getarmas);
        if(getarmas){
            throw new Error('Produto já cadastrado');
        }
        if (nome.length < 4 || nome.length > 60) {
            throw new Error('Nome do produto tem que ter entre 10 e 60 caracteres');
        }
        if (descricao.length < 10 || descricao.length > 500) {
            throw new Error('Descrição do produto deve ter entre 10 e 500 caracteres');
        }

        const armas = await armasRepository.createArmas({id: UUIDV4(), nome, descricao, preco});
        return armas;
    }

    async getByName(nome){
        return await armasRepository.findByName(nome);
    }

 
    async getarmas(){
        return await armasRepository.findAll();
    }
}

module.exports = new ArmasService();